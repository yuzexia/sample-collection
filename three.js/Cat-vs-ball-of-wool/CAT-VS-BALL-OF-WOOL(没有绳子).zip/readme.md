## Cat-vs-ball-of-wool

#### 改变背景颜色

- 将style中的main.css第7行代码改一下
- 将js中的main.js第114行color对象改一下